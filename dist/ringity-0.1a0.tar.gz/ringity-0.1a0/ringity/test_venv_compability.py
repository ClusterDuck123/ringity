def test():
    print("This is yet another test, lol.")
